﻿using UnityEngine;
using System.Collections;

public class Mover : MonoBehaviour 
{
	private float pingPongTimer = 0f;

	private void Update () 
	{
		pingPongTimer += Time.deltaTime *2f;

		transform.position = new Vector3(Mathf.PingPong(pingPongTimer, 6f) - 3f, transform.position.y, transform.position.z);
	}
}
