﻿using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour 
{
	private bool pixelSnappingEnabled = true;

	private bool zoomed = false;

	private bool enableMovement = true;

	private void OnGUI()
	{
		if (GUI.Button(new Rect(10, 10, 200, 25), pixelSnappingEnabled ? "Disable Pixel Grid Snapping" : "Enable Pixel Grid Snapping"))
		{
			pixelSnappingEnabled = !pixelSnappingEnabled;

			foreach (SnapToPixelGrid snapToPixelGrid in GameObject.FindObjectsOfType<SnapToPixelGrid>())
			{
				snapToPixelGrid.enabled = pixelSnappingEnabled;
			}
		}

		if (GUI.Button(new Rect(10, 45, 200, 25), zoomed ? "Unzoom" : "Zoom"))
		{
			zoomed = !zoomed;

			Camera.main.orthographicSize = zoomed ? 4f : 7.5f;
		}

		if (GUI.Button(new Rect(10, 80, 200, 25), enableMovement ? "Disable Movement" : "Enable Movement"))
		{
			enableMovement = !enableMovement;

			GameObject.FindObjectOfType<Mover>().enabled = enableMovement;
		}
	}
}
